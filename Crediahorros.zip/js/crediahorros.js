document.querySelectorAll('.dropdown a').forEach(link => {
  link.addEventListener('click', event => {
    if (link.target === '_blank') {
      // Permite que los enlaces con target="_blank" funcionen correctamente
      return;
    }

    // Para enlaces internos, puedes prevenir la acción predeterminada si es necesario
    event.preventDefault();
    console.log('Clic en enlace interno');
  });
});

document.addEventListener('DOMContentLoaded', () => {
  // RED DE CAJEROS
  const tarjetas = document.querySelectorAll('.tarjeta');
  tarjetas.forEach((tarjeta) => {
    tarjeta.addEventListener('click', (event) => {
      // Verificar si el clic fue sobre un enlace con target="_blank"
      const link = event.target.closest('a'); // Encuentra el enlace más cercano en el árbol del DOM
      if (link && link.target === '_blank') {
        return; // Permitir el comportamiento predeterminado del enlace
      }
      tarjeta.classList.toggle('girar'); // Agregar o quitar la clase "girar"
    });
  });

  // PUNTOS EFECTY, TARJETA DÉBITO
  document.querySelectorAll('.card').forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.style.transform = 'scale(1.05)';
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = 'scale(1)';
    });
  });
});


